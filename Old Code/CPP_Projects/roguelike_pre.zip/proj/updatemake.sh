echo
echo "Updating files..."

touch main.cpp
touch etc.cpp
touch Tile.cpp
touch Map.cpp
touch GenMap.cpp
touch Player.cpp
touch Object.cpp

echo
echo "Compiling and linking..."
echo

make

echo
echo "Done!"
echo
