#include "main.h"

Entity::Entity(int x_, int y_, int id_)
{
	x 	= 	x_;
	y 	= 	y_;
	id 	= 	id_;
	time_a = 0;
	// arbitrary max
	time_m = 1000;
}
Entity::~Entity() { }

// getters
int Entity::get_id()
{
	return id;
}
int Entity::get_x()
{
	return x;
}
int Entity::get_y()
{
	return y;
}
bool Entity::get_solid()
{
	return solid;
}
bool Entity::get_in_room()
{
	return in_room;
}

// setters
void Entity::set_id(int i)
{
	id = i;
}
void Entity::set_solid(bool solid_)
{
	solid = solid_;
}
void Entity::set_in_room(bool in_room_)
{
	in_room = in_room_;
}

// initialize main values (used in place of ctor, because adding vars to ctors is a hassle)
void Entity::init(bool solid_, bool in_room_) {
	solid = solid_;
	in_room = in_room_;
	rand_spawn();
}

void Entity::update(int time)
{
	int old_x = x;
	int old_y = y;
	
	time_a += time;
	if (time_a >= time_m)
	{
		time_a = 0;
		//make_changes();
	}
	// if position has changed
	if (old_x != x || old_y != y)
	{
		//map.get_area()->get_tile(old_x, old_y)->free_ent
	}
}

void Entity::move(int dir) { }

void Entity::rand_spawn()
{
	// TODO: attribute "solidness" to each ID
	Map *area = game.get_area();
	int x_ = (rand() % (area->get_width() - 2)) + 1;
	int y_ = (rand() % (area->get_height() - 2)) + 1;
	// while we are still spawning in a wall
	while (area->get_tile(x_, y_)->get_solid()
		// and we are not in a room
		|| !area->get_tile(x_, y_)->get_in_room())
	{
		// generate new random coordinates
		x_ = (rand() % (area->get_width() - 2)) + 1;
		y_ = (rand() % (area->get_height() - 2)) + 1;
	}
	// found right coordinates; assign them to x and y
	x = x_;
	y = y_;
	area = NULL;
}
