#ifndef HANDLER_H
#define HANDLER_H

class Handler
{
private:

public:
	Handler();
	~Handler();
	void handle(Event);
};

#endif // HANDLER_H
