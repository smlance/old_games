#ifndef GFX_H
#define GFX_H

#include "SDL/SDL_image.h"
#include "SDL/SDL.h"

#endif // GFX_H
