#!/bin/bash

#touch *
g++ *.cpp -o jarl-lap -lSDL -lSDLmain -lSDL_image -g
rm -f *.o
