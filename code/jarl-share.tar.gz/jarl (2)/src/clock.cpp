#include "main.h"

Clock::Clock()
{
	time_init = 0;
}
Clock::~Clock() { }

void Clock::start()
{
	time_init = SDL_GetTicks();
}

int Clock::get_time_elapsed()
{
	return SDL_GetTicks() - time_init;
}
