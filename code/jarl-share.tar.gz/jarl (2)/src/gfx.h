#ifndef GFX_H
#define GFX_H

#include "SDL/SDL.h"
#include "SDL/SDL_image.h"

#endif // GFX_H
